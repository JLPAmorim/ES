<template>
  <v-footer class="footer" style="background-color: #00302e; color: #e6f0ef">
    <v-row justify="center" no-gutters>
      <v-col class="text-center mt-4" cols="12">
        {{ new Date().getFullYear() }}/{{ new Date().getFullYear() + 1 }} - <strong>MailUM</strong>
      </v-col>
    </v-row>
  </v-footer>
</template>

<script>

</script>
